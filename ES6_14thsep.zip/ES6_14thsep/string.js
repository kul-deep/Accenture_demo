var str="Hello World"
console.log(str.toLowerCase());
console.log(str.toUpperCase());

console.log("str.charAt(0) is"+str.charAt(0));
console.log("str.charAt(1) is"+str.charAt(1));

var str1="hai"
var str2="hello"

var str3 = str1.concat(str2)

console.log("str1 + str2:"+str3)