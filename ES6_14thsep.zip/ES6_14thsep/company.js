function f1(...params){
    console.log(params.length);
}
f1(5)
f1()
f1(5,7,8,4)