// var mycar = new Object()
// mycar.make="ford"
function car(){
    this.model="mustang"
    this.year="1988"
}
var obj =new car()
console.log(obj.model);
console.log(obj.year);