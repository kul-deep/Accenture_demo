let bal=5000;
console.log(typeof bal);
let bal={message:"hello"};
console.log(typeof bal);
