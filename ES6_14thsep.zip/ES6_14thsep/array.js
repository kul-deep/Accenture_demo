var alphs;
alphs=["1","2","3","4"]
console.log(alphs[0]);
console.log(alphs[1]);

for(var i=0;i<alphs.length();i++){
    console.log(alphs[i]);
}

var num=[1,2,3,4,5]
console.log(num[0]);
console.log(num[1]);
console.log(num[3]);
