var dt = Date();
var dt1 = new Date("September 16, 2021 11:37:56");


console.log("current date",dt);
console.log("current date",dt1.getDate());
console.log("current date",dt1.getDay());
console.log("current date",dt1.getMinutes());
console.log("current date",dt1.getHours());