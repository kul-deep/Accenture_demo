class staticmem{
    static disp(){
        console.log("static fun called");
    }
}
staticmem.disp();