var grade="A"

switch (grade) {
    case "A":
        console.log("Excellent");
        break;
    case "B":
        console.log("Good");
        break;

    default:
        console.log("poor");
        break;
}