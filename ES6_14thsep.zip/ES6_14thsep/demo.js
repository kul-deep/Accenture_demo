var a = "hello"
console.log(a)