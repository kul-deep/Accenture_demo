x=3.14
myfun();
function myfun(){
    "use strict"
    y=3.56
}
console.log(x);